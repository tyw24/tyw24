Group Members: Micheal Luker(mtl63), Tiffany Wong(tyw24), and Eric Saputra(es636)

Name of the App: Dash and Dine

Purpose: To provide students a food-truck delivery service for a small fee

Michael was tasked with storing the food truck information, dealing with a customer order, and placing that order into cloud-mine, .
Tiffany was tasked to create the login menu and messaging board. She also created the icon for the app
Eric was tasked with the GPS Location for the deliverer's phone to allow the buyer to know where exactly their food is

Limitations:
	Contacting the deliverer does not currently work
		Implementing the messaging system
	GPS does not currently work
		Android's location class was very difficult to work with
		Could not figure out how to update the deliverer's phone location
	Learning how to use cloudmine was somewhat difficult
		Learning curve was very steep

Walkthrough of Application:
The application should run from the apk file included. Upon opening the application you come to a login screen which currently takes anything as input. Once logged in, you come to a screen with four buttons. The customer button allows you to place an order from the stored food trucks. Once a food truck is selected the get menu button must be pressed to get menu items for that food truck. The other two fields to be entered are address and additional notes, which is used for any special instructions you might want to enter. To go back an activity, the deliverer button is not yet implemented. The view customer button shows a map of all available customers and all food cars. The view deliver button is currently just a map with one fixed point on it. 