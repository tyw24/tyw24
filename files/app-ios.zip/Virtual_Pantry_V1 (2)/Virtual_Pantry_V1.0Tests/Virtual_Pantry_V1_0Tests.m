//
//  Virtual_Pantry_V1_0Tests.m
//  Virtual_Pantry_V1.0Tests
//
//  Created by Stevie Parris on 4/29/2014.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Virtual_Pantry_V1_0Tests : XCTestCase

@end

@implementation Virtual_Pantry_V1_0Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
