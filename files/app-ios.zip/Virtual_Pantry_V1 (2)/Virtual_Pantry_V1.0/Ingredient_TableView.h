//
//  Ingredient TableView.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 5/19/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

@class Ingredient_TableView;

@protocol Ingredient_TableViewDelegate
- (void)Ingredient_TableViewDidFinish:(Ingredient_TableView *)controller;
@end


#import <UIKit/UIKit.h>
#import "Page3.h"



@interface Ingredient_TableView : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>

@property (weak, nonatomic) id <Ingredient_TableViewDelegate> delegate;

@property (strong, nonatomic) NSMutableArray *addedObjects;
@property (strong, nonatomic) NSArray *searchResults;
@property (weak, nonatomic) IBOutlet UITableView *ingredientSearch;
@property (strong, nonatomic) NSString *holder1;
@property (strong, nonatomic) NSMutableDictionary *dictholder;
@property (weak, nonatomic) IBOutlet UISearchBar *Search_Box;

- (IBAction)Done_Button:(id)sender;

- (void)tableView: (UITableView *)tableView didSelectRowAtIndexPath: (NSIndexPath *)indexPath;

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar;

@end