//
//  FoodCell.m
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/14/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import "FoodCell.h"

@implementation FoodCell

@end
