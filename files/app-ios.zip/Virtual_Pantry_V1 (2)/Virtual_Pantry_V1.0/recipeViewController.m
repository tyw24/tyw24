//
//  recipeViewController.m
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/16/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import "recipeViewController.h"
#import "nutritionViewController.h"
#import "AppDelegate.h"

@interface recipeViewController ()

@end

@implementation recipeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _holdFavs = [[NSMutableArray alloc] init];
    
    
    [self callToWeb];
    // Do any additional setup after loading the view

    
    // USE THIS TO GET THE ITEMS IN PANTRY: _appDelegate.myPantry.inventoryArray
    
    //Making the border
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"BlueBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    // Including an image of the recipe
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    NSString *imageURLString =[[[[_getResults valueForKey:@"images"] valueForKey:@"imageUrlsBySize"]valueForKey:@"360"] objectAtIndex:0];
    
    NSURL *url = [NSURL URLWithString:imageURLString];
    NSData *data = [[NSData alloc] initWithContentsOfURL:url];
    UIImage *image1 = [UIImage imageWithData:data];
    [_recipeImageF setImage:image1];
    
    
    //Making the title for the food
    [_titleF setText:[_getResults valueForKey:@"name"]];
    [_titleF setNumberOfLines:0];
    [_titleF setFont:[UIFont fontWithName:@"ArialBold" size:9.0]];
    [_titleF setTextAlignment:NSTextAlignmentNatural];
    _titleF.lineBreakMode = NSLineBreakByWordWrapping;
    [_titleF setTextColor:[[UIColor alloc] initWithWhite:0 alpha:1]];
    
    //Making the rating label for the food
    int rating = [[_getResults valueForKey:@"rating"] intValue];
    
    switch (rating) {
        case 1: [_ratingF setImage:[UIImage imageNamed:@"1Star.png"]];
            break;
        case 2: [_ratingF setImage:[UIImage imageNamed:@"2Star.png"]];
        case 3: [_ratingF setImage:[UIImage imageNamed:@"3Star.png"]];
            break;
        case 4: [_ratingF setImage:[UIImage imageNamed:@"4Star.png"]];
            break;
        case 5: [_ratingF setImage:[UIImage imageNamed:@"5Star.png"]];
            break;
        default:
            break;
    }
    
    /*[_ratingF setText:[@"Rating: " stringByAppendingString:[[[_getResults valueForKey:@"rating"] stringValue] stringByAppendingString:@"/5"]]];*/
    
    //Showing ingredients
    NSString *ingredients = [NSString alloc];
    
    _ingredientsF.text =  @"";
    //_ingredientsF = [UILabel alloc];
    for(int i = 0; i < [[_getResults valueForKey:@"ingredientLines"] count]; i++)
    {
        ingredients = [[_getResults valueForKey:@"ingredientLines"] objectAtIndex:i];
        [ingredients stringByAppendingString:@"\n"];
        
        _ingredientsF.text = [[_ingredientsF.text stringByAppendingString:ingredients] stringByAppendingString:@"\n"];
    }
  
    [_ingredientsF setFont:[UIFont fontWithName:@"ArialBold" size:9.0]];
    [_ingredientsF setTextAlignment:NSTextAlignmentNatural];
    
    //Setting calories label
    NSString *cps = @"Calories per Serving: ";
    NSString *calories;
    NSLog(@"%@", [_getResults valueForKey:@"nutritionEstimates"]);
    @try{
        calories = [[[[_getResults valueForKey:@"nutritionEstimates"] objectAtIndex:0] valueForKey:@"value"]stringValue]; // causes crash for some ingredients without nutrition estimates as a vector-- check this
    }
    @catch(NSException *exception){
        calories = @"";
    }
    _caloriesPerServing.text = [cps stringByAppendingString:calories];
    [_caloriesPerServing setFont:[UIFont fontWithName:@"ArialBold" size:8.0]];
    [_caloriesPerServing setTextAlignment:NSTextAlignmentNatural];
    [_caloriesPerServing setTextColor:[[UIColor alloc] initWithWhite:0 alpha:1]];
    //Setting number of servings
    NSString *nos = @"Servings: ";
    NSString *servings = [[_getResults valueForKey:@"numberOfServings"] stringValue];
    _servingsF.text = [nos stringByAppendingString: servings];
    [_servingsF setFont:[UIFont fontWithName:@"ArialBold" size:8.0]];
    [_servingsF setTextAlignment:NSTextAlignmentNatural];
    [_servingsF setTextColor:[[UIColor alloc] initWithWhite:0 alpha:1]];
    
    //Setting cook time
    NSString *ct = @"Cook Time: ";
    NSString *time = [_getResults valueForKey:@"totalTime"];
    
    if([_getResults valueForKey:@"totalTime"] == [NSNull null])
        time = @"No cook time available";
    _cookTimeF.text = [ct stringByAppendingString:time];
    [_cookTimeF setFont:[UIFont fontWithName:@"ArialBold" size:8.0]];
    [_cookTimeF setTextAlignment:NSTextAlignmentNatural];
    [_cookTimeF setTextColor:[[UIColor alloc] initWithWhite:0 alpha:1]];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)callToWeb {

    
    // if([_singleRecipe objectAtIndex:5] == nil){ [_singleRecipe setObject:@"1" atIndexedSubscript:5];}
    NSString *getURLName = [@"http://api.yummly.com/v1/api/recipe/" stringByAppendingString:[_singleRecipe objectAtIndex:5]];
    
    getURLName = [getURLName stringByAppendingString:@"?_app_id=4463c582&_app_key=826ed0572175a6597d8e748bee827d66"];
    
    NSURL *getURL = [NSURL URLWithString:[getURLName stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding]];
    
    NSData *getResultsDictionary = [NSData dataWithContentsOfURL:getURL];
    
    @try {
        _getResults = [NSJSONSerialization
                          JSONObjectWithData:getResultsDictionary
                          options:NSJSONReadingMutableContainers
                          error:nil];
        
        _appDelegate2 = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        _appDelegate2.recipeInformation = _getResults;
    }
    @catch (NSException *exception) {
        NSLog(@"error in recipeViewController.m");
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([[segue identifier] isEqualToString:@"nutritionViewSegue"]) {
         nutritionViewController *controller = (nutritionViewController *)segue.destinationViewController;
         controller.singleRecipe = _singleRecipe;
    }
}

- (IBAction)addFavorite:(id)sender {
    [_holdFavs addObject:_getResults];
}

- (IBAction)Back:(id)sender {
    //reassign values based on new entries
    [[self view] endEditing:YES]; //get rid of keyboard
    
    [self.delegate recipeViewControllerDidFinish:self];
}

- (IBAction)webRecipe:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[[_getResults valueForKey:@"source"] valueForKey: @"sourceRecipeUrl"]]];
}

@end
