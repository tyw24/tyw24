//
//  FoodCell.h
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/14/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *homeImage;
@property (strong, nonatomic) IBOutlet UILabel *homeName;

@property (strong, nonatomic) IBOutlet UIImageView *recipeImage;
@property (strong, nonatomic) IBOutlet UILabel *recipeName;

@end
