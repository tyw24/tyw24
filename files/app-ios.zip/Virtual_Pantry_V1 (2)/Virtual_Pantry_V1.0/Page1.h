//
//  Page1.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VPRecipe.h"
#import "AppDelegate.h"
#import "FoodCell.h"

@interface Page1 : UIViewController <UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, AppDelegate>


@property (strong, nonatomic) UIAlertView *failure;
@property (strong, nonatomic) UIAlertView *failure2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
//The delegate used to get data back and forth
@property (weak, nonatomic) IBOutlet UIImageView *blandPicture;
@property(nonatomic,assign)id delegate;
//Declare the app delegate
@property (strong, nonatomic) AppDelegate *appDelegate;

- (IBAction)dismissKeyboardOnTap:(id)sender;

@end