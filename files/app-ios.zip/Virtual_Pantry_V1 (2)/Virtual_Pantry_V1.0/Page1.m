//
//  Page1.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import "Page1.h"
#import <QuartzCore/QuartzCore.h>

#import "recipeViewController.h"

@interface Page1 ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@end

@implementation Page1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //NSLog(@"%@", _appDelegate.favoriteRecipes.inventoryArray);
    // Do any additional setup after loading the view.
    
    UIImage *homeImage = [UIImage imageNamed:@"Home.png"];
    self.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Home" image:homeImage tag:0];
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"HighWoodBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    
    //Declare App Delegate in page
    _appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //NSLog(@"%@", _appDelegate.favoriteRecipes.inventoryArray);
    
    
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    [_imageView setImage: image];
    
    
    //UIGraphicsBeginImageContext(self.view.frame.size);
    [_imageView2 setImage:[UIImage imageNamed: @"StickyNote.png"]];
    [_blandPicture setImage:[UIImage imageNamed:@"general_tsaos.png"]];
    //UIGraphicsEndImageContext();
    //[_imageView2 setImage: image2];
    
    //error messages
    _failure = [[UIAlertView alloc]
                initWithTitle:@"Error"
                message:@"You left the text box blank."
                delegate:nil
                cancelButtonTitle:@"Uh.. Okay.."
                otherButtonTitles:nil];
    _failure2 = [[UIAlertView alloc]
                 initWithTitle:@"Error"
                 message:@"Undiagnosed error."
                 delegate:nil
                 cancelButtonTitle:@"Hmm.."
                 otherButtonTitles:nil];
}

//This makes it so you can click off the keyboard and it will disappear.
- (IBAction)dismissKeyboardOnTap:(id)sender {
    [[self view] endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [_appDelegate.favoriteRecipes.inventoryArray count];
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(158, 158);
}

-(void)setupCollectionView {
    [self.collectionView registerClass:[FoodCell class] forCellWithReuseIdentifier:@"homefoodViewCell"];
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    [flowLayout setMinimumInteritemSpacing:0.0f];
    [flowLayout setMinimumLineSpacing:3];
    
    [self.collectionView setPagingEnabled:NO];
    [self.collectionView setCollectionViewLayout:flowLayout];
    
    [self.collectionView reloadData];
    
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FoodCell *cell = (FoodCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"homeViewCell" forIndexPath:indexPath];
    
    //[cell.homeImage setImage:[_appDelegate.favoriteRecipes.inventoryArray objectAtIndex:indexPath.row]];
    
    /*UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 158, 158)];
    [imageView setImage:[[[[_appDelegate.favoriteRecipes.inventoryArray objectAtIndex:indexPath.row] valueForKey:@"images"] valueForKey:@"imagesUrlsBySize"]valueForKey:@"360"];
    [[cell contentView] addSubview:imageView];
    
    UILabel *imageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,88,120,70)];
    [imageLabel setText:_recipesArray[indexPath.row]];
    [imageLabel setNumberOfLines:0];
    [imageLabel setFont:[UIFont fontWithName:@"ArialBold" size:9.0]];
    [imageLabel setTextAlignment:NSTextAlignmentNatural];
    imageLabel.lineBreakMode = NSLineBreakByWordWrapping;
    
    [imageLabel setTextColor:[[UIColor alloc] initWithWhite:1 alpha:1]];
    imageLabel.backgroundColor = [[UIColor alloc] initWithWhite:.5 alpha:.4];
    [[cell contentView] addSubview:imageLabel];*/
    
    return cell;
}

@end
