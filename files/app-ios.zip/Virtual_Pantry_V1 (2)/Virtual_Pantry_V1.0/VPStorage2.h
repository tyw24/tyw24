//
//  VPRecipeDatabase.h
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/13/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VPStorage2.h"

@interface VPStorage2 : NSObject <NSCoding>


@property (strong, nonatomic) NSMutableArray *inventoryArray;

- (void) addItem: (NSString *) anItem;

- (NSMutableArray *) toArray;
- (void) changeArray: (NSMutableArray *) newArray;

- (void) encodeWithCoder: (NSCoder *) aCoder;

- (void) save;

- (id)initWithCoder:(NSCoder *)aDecoder;

// + (id)inventoryArray;

@end
