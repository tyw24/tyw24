//
//  VPRecipe.m
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/13/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import "VPRecipe.h"

@implementation VPRecipe
//need a method in which we can write the attributes array to the array in a recipe -- think about it

-(id) initWithArray:(NSMutableArray *) attributes
{
    self = [super init];
    if (self)
    {
        _attributeArray = [[NSMutableArray alloc] init];
        _nameArray = [[NSMutableArray alloc] init];
        _pictureArray = [[NSMutableArray alloc] init];
        _ingredientsArray = [[NSMutableArray alloc]init];
        _ratingArray = [[NSMutableArray alloc] init];
        _timeArray = [[NSMutableArray alloc] init];
        _idArray = [[NSMutableArray alloc]init];
        _courseArray = [[NSMutableArray alloc] init];
        
        _attributeArray = [attributes valueForKey:@"matches"];
        //NSLog(@"%@", _attributeArray);
        for(NSDictionary *recipes in _attributeArray)
        {
            NSString *tempName = [NSString alloc];
            if(recipes[@"recipeName"] == [NSNull null]){
                tempName = @"";
            }
            else{
                tempName = recipes[@"recipeName"];
            }
            
            UIImage *tempPicture = recipes[@"imageUrlsBySize"];
            NSString *tempIngredients = [NSString alloc];
            if(recipes[@"ingredients"] == [NSNull null]){
                tempIngredients = @"";
            }
            else{
                tempIngredients = recipes[@"ingredients"];
            }
            
            NSNumber *tempRating = [NSNumber alloc];
            if(recipes[@"rating"] == [NSNull null]){
                tempRating = [NSNumber numberWithInt:0];
            }
            else{
                tempRating = recipes[@"rating"];
            }
            
            NSNumber *tempTime = [NSNumber alloc];
            if(recipes[@"totalTimeInSeconds"] == [NSNull null]){
                tempTime = [NSNumber numberWithInt:0];
            }
            else{
                tempTime = @([recipes[@"totalTimeInSeconds"] integerValue]);
            }
            
            NSString *tempCourse = [NSString alloc];
            if(recipes[@"course"] == [NSNull null]){
                tempCourse = @"";
            }
            else{
                tempCourse = recipes[@"course"];
            }
            
            NSString *tempid = [NSString alloc];
            if(recipes[@"id"] == [NSNull null]){
                tempid = @"";
            }
            else{
                tempid = recipes[@"id"];
            }

            [_nameArray addObject: tempName];
            [_pictureArray addObject:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[tempPicture valueForKey:@"90"]]]]];
            [_ingredientsArray addObject: tempIngredients];
            [_ratingArray addObject:tempRating];
            [_timeArray addObject: tempTime];
            // [_courseArray addObject:[tempCourse valueForKey:@"course"]];
            [_idArray addObject:tempid];
        }
    }
    return self;
}


-(NSMutableArray *)recipeName
{
    return _nameArray;
}

-(NSMutableArray *)recipeImage
{
    return _pictureArray;
}

-(NSMutableArray *)recipeIngredients
{
    return _ingredientsArray;
}

-(NSMutableArray  *)recipeRating
{
    return _ratingArray;
}

-(NSMutableArray*)recipeCookTime
{
    return _timeArray;
}

-(NSMutableArray*)recipeCourse
{
    return _courseArray;
}

@end
