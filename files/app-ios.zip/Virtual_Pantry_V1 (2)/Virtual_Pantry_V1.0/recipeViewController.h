//
//  recipeViewController.h
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/16/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VPRecipe.h"
#import "Page1.h"

@class AppDelegate;

@class recipeViewController;

@protocol recipeViewControllerDelegate

- (void)recipeViewControllerDidFinish:(recipeViewController *)controller;

@end

@interface recipeViewController:UIViewController

@property (strong, nonatomic) AppDelegate *appDelegate2;
@property (weak, nonatomic) id <recipeViewControllerDelegate> delegate;

@property (strong, nonatomic) NSMutableArray *getResults;
@property (strong, nonatomic) NSMutableArray *singleRecipe;
@property(strong ,nonatomic) NSMutableArray *holdFavs;
- (IBAction)addFavorite:(id)sender;

- (IBAction)Back:(id)sender;
- (IBAction)webRecipe:(id)sender;

@property (strong, nonatomic) IBOutlet UIImageView *recipeImageF;
@property (weak, nonatomic) IBOutlet UILabel *titleF;
@property (weak, nonatomic) IBOutlet UIImageView *ratingF;
@property (weak, nonatomic) IBOutlet UITextView *ingredientsF;
@property (weak, nonatomic) IBOutlet UILabel *caloriesPerServing;
@property (weak, nonatomic) IBOutlet UILabel *servingsF;
@property (weak, nonatomic) IBOutlet UILabel *cookTimeF;


@end
