//
//  Ingredient TableView.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 5/19/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import "Page3.h"

@interface Ingredient_TableView ()

@end

@implementation Ingredient_TableView

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"YellowBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    
    [self.Search_Box setDelegate:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//TBC (To Be Created)
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

//TBC (To Be Created)
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_searchResults count];
}

//TBC (To Be Created)
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [_searchResults objectAtIndex:indexPath.row];
    [cell setBackgroundColor:[UIColor clearColor]];
    [cell.textLabel setBackgroundColor:[UIColor clearColor]];
    return cell;
}

- (BOOL)tableViewShouldReturn:(UITextField *)textField {
    
    return YES;
}

//TBC (To Be Created)
- (IBAction)begin_search:(id)sender {
    
    
    NSString *searchURLName = @"http://api.yummly.com/v1/api/metadata/ingredient?_app_id=4463c582&_app_key=826ed0572175a6597d8e748bee827d66";
    NSURL *searchURL = [NSURL URLWithString:searchURLName];
    NSData *searchResultsDictionary = [NSData dataWithContentsOfURL:searchURL];
    
    NSString *html = [[NSString alloc] initWithData:searchResultsDictionary encoding:NSUTF8StringEncoding];
    NSRange aRange = NSMakeRange(26, [html length] - 28);
    
    
    html = [html substringWithRange:aRange];
    
    searchResultsDictionary = [html dataUsingEncoding:NSUTF8StringEncoding];
    
    
    NSArray *results = [NSJSONSerialization
                        JSONObjectWithData:searchResultsDictionary
                        options:NSJSONReadingMutableContainers
                        error:nil];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"searchValue contains[cd] %@", _Search_Box.text]; // if you need case sensitive search avoid '[c]' in the predicate
    
    _searchResults = [results filteredArrayUsingPredicate:predicate];
    _searchResults = [_searchResults valueForKey:@"term"];
    
    [[self view] endEditing:YES];
    [_ingredientSearch performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
    

}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    
    searchBar.delegate = self;
    
    NSString *searchURLName = @"http://api.yummly.com/v1/api/metadata/ingredient?_app_id=4463c582&_app_key=826ed0572175a6597d8e748bee827d66";
    NSURL *searchURL = [NSURL URLWithString:searchURLName];
    NSData *searchResultsDictionary = [NSData dataWithContentsOfURL:searchURL];
    
    NSString *html = [[NSString alloc] initWithData:searchResultsDictionary encoding:NSUTF8StringEncoding];
    NSRange aRange = NSMakeRange(26, [html length] - 28);
    
    
    html = [html substringWithRange:aRange];
    
    searchResultsDictionary = [html dataUsingEncoding:NSUTF8StringEncoding];
    
    
    NSArray *results = [NSJSONSerialization
                        JSONObjectWithData:searchResultsDictionary
                        options:NSJSONReadingMutableContainers
                        error:nil];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"searchValue contains[cd] %@", _Search_Box.text]; // if you need case sensitive search avoid '[c]' in the predicate
    
    _searchResults = [results filteredArrayUsingPredicate:predicate];
    _searchResults = [_searchResults valueForKey:@"term"];
    
    [_ingredientSearch performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
    
    if([_searchResults count] != 0)
        [[self view] endEditing:YES]; //get rid of keyboard
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Added To Pantry" message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    
    //add object at row to an array
    [_addedObjects addObject:[_searchResults objectAtIndex:indexPath.row]];
}

#pragma mark - Actions
- (IBAction)Done_Button:(id)sender
{
    //FOR PASSING DATA BETWEEN CONTROLLERS
    //declare controller of type page 3, let's you access the values inside that viewcontroller
    Page3 * acontollerobject=[[Page3 alloc] init];
     // protocol listener
    acontollerobject.delegate=self;
    //push values to viewcontroller
    [self.navigationController pushViewController:acontollerobject animated:YES];
    //reassign values based on new entries
    [[self view] endEditing:YES]; //get rid of keyboard
    acontollerobject.appDelegate.myPantry.inventoryArray = _addedObjects;
    //finish tableview, call finish function
    [self.delegate Ingredient_TableViewDidFinish:self];
}

@end
