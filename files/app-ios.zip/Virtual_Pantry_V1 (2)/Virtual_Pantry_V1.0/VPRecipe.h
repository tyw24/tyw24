//
//  VPRecipe.h
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/13/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VPRecipe : NSObject

//@property (strong, nonatomic) NSArray *recipeTitle;
@property (strong, nonatomic) NSArray *attributeArray;
@property (strong, nonatomic) NSMutableArray *nameArray;
@property (strong, nonatomic) NSMutableArray *pictureArray;
@property (strong, nonatomic) NSMutableArray *ingredientsArray;
@property (strong, nonatomic) NSMutableArray *ratingArray;
@property (strong, nonatomic) NSMutableArray *timeArray;
@property (strong, nonatomic) NSMutableArray *courseArray;
@property (strong, nonatomic) NSMutableArray *idArray;

@property (strong, nonatomic) NSString *recipeName;
//@property (strong, nonatomic) NSString *ingredients;
//@property (strong, nonatomic) NSNumber *recipeRating;
//@property (strong, nonatomic) NSNumber *cookTime;


-(NSString *)recipeName;

-(NSMutableArray *)recipeImage;

-(NSMutableArray *)recipeIngredients;

-(NSMutableArray *)recipeRating;

-(NSMutableArray*)recipeCookTime;

-(NSMutableArray*)recipeCourse;


-(id) initWithArray:(NSMutableArray *) attributes;

@end
