//
//  namesFlipsideViewController.h
//  Assignment2_P2
//
//  Created by Edward Aryee on 4/28/14.
//  Copyright (c) 2014 EdwardAryee_ENGR103. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "recipeViewController.h"
#import "FoodCell.h"
#import "VPRecipe.h"
#import "Page2.h"

@class namesFlipsideViewController;

@protocol namesFlipsideViewControllerDelegate
- (void)namesFlipsideViewControllerDidFinish:(namesFlipsideViewController *)controller;
@end

@interface namesFlipsideViewController : UIViewController <UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (weak, nonatomic) id <namesFlipsideViewControllerDelegate> delegate;

@property (strong, nonatomic) UIAlertView *easterEgg;

@property (strong, nonatomic) VPRecipe * superRecipe;
@property (strong, nonatomic) NSMutableArray *singleRecipePassing;
@property (strong, nonatomic) NSMutableArray *transportArray2;
@property (strong, nonatomic) NSMutableArray *searchResults1;
@property (strong, nonatomic) NSMutableArray *recipesArray;
@property (strong, nonatomic) NSMutableArray *picturesArray;

- (void)recipeViewControllerDidFinish:(namesFlipsideViewController *) controller;

- (IBAction)Done_Button:(id)sender;

@end
