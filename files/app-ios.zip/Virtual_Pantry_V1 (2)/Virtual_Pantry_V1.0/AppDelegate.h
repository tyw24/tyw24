//
//  AppDelegate.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/29/2014.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//


@class AppDelegate;

@protocol AppDelegate
@end

#import <UIKit/UIKit.h>
#import "Page3.h"
#import "VPStorage2.h"



@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) NSMutableArray *recipeInformation;

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,retain) VPStorage *myPantry;

@property (nonatomic, retain) VPStorage2 *favoriteRecipes;


//Initialize data saving module
- (id)init:(int*) x;

@end
