//
//  nutritionViewController.h
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/31/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppDelegate;

@interface nutritionViewController : UIViewController //<AppDelegate>

//Declare the app delegate
@property (strong, nonatomic) AppDelegate *appDelegate;

@property (weak, nonatomic) IBOutlet UILabel *nutrientName;
@property (strong, nonatomic) NSMutableArray *singleRecipe;

@end
