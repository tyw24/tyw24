//
//  MyManager.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 5/23/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import <foundation/Foundation.h>
#import "VPStorage.h"

@interface MyManager : NSObject {
    VPStorage *storageObject;
}

@property (nonatomic, retain) VPStorage *storageObject;

+ (id)sharedManager;

- (void)updateStorageObject: (VPStorage *) newObject;

@end