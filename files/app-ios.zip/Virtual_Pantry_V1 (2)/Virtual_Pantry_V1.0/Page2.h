//
//  Page2.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "namesFlipsideViewController.h"

@class namesFlipsideViewController;

@interface Page2 : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource, AppDelegate>

@property (strong, nonatomic) UIAlertView *failure;
@property (strong, nonatomic) UIAlertView *failure2;

@property bool pantryActivated;

@property (weak, nonatomic) IBOutlet UITextField *search;

@property BOOL *allergy1p;

//Declare the app delegate
@property (strong, nonatomic) AppDelegate *appDelegate;

@property (strong, nonatomic) NSMutableArray *searchArray;
@property (strong, nonatomic) NSMutableArray *transportArray;

@property (strong, nonatomic) NSString *recipeResultsFile;

@property (strong, nonatomic) NSMutableArray *searchResults;

- (IBAction)useAllPantryItems:(id)sender;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (strong, nonatomic) NSMutableArray *selectedItems;
@property (strong, nonatomic) NSArray *allergiesDiets;

- (IBAction)GetRecipesAndShow:(id)sender;

- (IBAction)dismissKeyboardOnTap:(id)sender;

- (IBAction)itemAllRecipes:(id)sender;

#pragma mark - Flipside View

- (void)namesFlipsideViewControllerDidFinish:(namesFlipsideViewController *)controller;

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;

@end