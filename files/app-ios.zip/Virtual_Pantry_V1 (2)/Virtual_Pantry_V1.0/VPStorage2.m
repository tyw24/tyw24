//
//  VPRecipeDatabase.m
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/13/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import "VPStorage2.h"

@implementation VPStorage2

#pragma mark Singleton Methods

+ (id)sharedArray {
    static VPStorage2 *sharedArray = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedArray = [[self alloc] init];
    });
    return sharedArray;
}

-(id) init
{
    self = [super init];
    if (self)
    {
        _inventoryArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}


- (void) addItem:(NSString *) anItem
{
    [_inventoryArray addObject: anItem];
}

- (NSMutableArray *) toArray
{
    return _inventoryArray;
}


- (void) changeArray:(NSMutableArray *)newArray
{
    NSLog(@"%@" , [[_inventoryArray arrayByAddingObjectsFromArray:newArray] mutableCopy]);
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    
    if(self)
    {
        _inventoryArray = [aDecoder decodeObjectForKey:@"inventory"];
        if(_inventoryArray == nil)
        {
            _inventoryArray = [[NSMutableArray alloc] init];
        }
    }
    
    return self;
}

- (void) encodeWithCoder: (NSCoder *) aCoder
{
    [aCoder encodeObject:_inventoryArray forKey:@"inventory"];
}

- (void) save
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *filePath = [NSString stringWithFormat:@"%@/database2", documentsDirectory];
    
    [NSKeyedArchiver archiveRootObject:self toFile:filePath];
    
}

@end
