//
//  namesFlipsideViewController.m
//  Assignment2_P2
//
//  Created by Edward Aryee on 4/28/14.
//  Copyright (c) 2014 EdwardAryee_ENGR103. All rights reserved.
//

#import "namesFlipsideViewController.h"
#import "FoodCell.h"
#import "recipeViewController.h"

@interface namesFlipsideViewController ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation namesFlipsideViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _easterEgg = [[UIAlertView alloc]
                initWithTitle:@"You Found: *EASTER EGG* "
                message:@"Congratulations"
                delegate:nil
                cancelButtonTitle:@"Collect easter egg!"
                otherButtonTitles:nil];
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"BlueBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    
    
    _superRecipe = [[VPRecipe alloc] initWithArray:_searchResults1];
    //if you don't allocate it, it won't let you write to it, learned the hard way
    
    _recipesArray = [NSMutableArray alloc];
    _picturesArray = [NSMutableArray alloc];
    
    _recipesArray = _superRecipe.nameArray;
    _picturesArray = _superRecipe.recipeImage;
    
    [self setupCollectionView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Setting up shake easter egg///////////////////////////////////////
- (void)viewDidAppear:(BOOL)animated {
    
    [self becomeFirstResponder];
}

- (void)viewDidDisappear:(BOOL)animated {
    
    [self becomeFirstResponder];
}

- (BOOL)canBecomeFirstResponder {
    return YES;
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    [_easterEgg show];
}
/////////////////////////////////////////////////////////////////////

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [_picturesArray count];
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(158, 158);
}

-(void)setupCollectionView {
    [self.collectionView registerClass:[FoodCell class] forCellWithReuseIdentifier:@"foodViewCell"];
    
   UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    [flowLayout setMinimumInteritemSpacing:0.0f];
    [flowLayout setMinimumLineSpacing:3];
    [self.collectionView setPagingEnabled:NO];
    [self.collectionView setCollectionViewLayout:flowLayout];
    
    [self.collectionView reloadData];

}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    FoodCell *cell = (FoodCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"foodViewCell" forIndexPath:indexPath];
    
    [cell.recipeImage setImage:[_picturesArray objectAtIndex:indexPath.row]];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 158, 158)];
    [imageView setImage:_picturesArray[indexPath.row]];
    [[cell contentView] addSubview:imageView];
    
    UILabel *imageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,88,120,70)];
    [imageLabel setText:_recipesArray[indexPath.row]];
    [imageLabel setNumberOfLines:0];
    [imageLabel setFont:[UIFont fontWithName:@"ArialBold" size:9.0]];
    [imageLabel setTextAlignment:NSTextAlignmentNatural];
    imageLabel.lineBreakMode = NSLineBreakByWordWrapping;
  
    [imageLabel setTextColor:[[UIColor alloc] initWithWhite:1 alpha:1]];
    imageLabel.backgroundColor = [[UIColor alloc] initWithWhite:.5 alpha:.4];
    [[cell contentView] addSubview:imageLabel];
    
    return cell;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"recipeViewSegue"]) {
        recipeViewController *controller = (recipeViewController *)segue.destinationViewController;
        controller.singleRecipe = _singleRecipePassing;
        
        [[segue destinationViewController] setDelegate:self];
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
   _singleRecipePassing = [[NSMutableArray alloc] init];
    [_singleRecipePassing addObject:[_superRecipe.nameArray objectAtIndex:indexPath.row]];
    [_singleRecipePassing addObject:[_superRecipe.pictureArray objectAtIndex:indexPath.row]];
    [_singleRecipePassing addObject:[_superRecipe.ingredientsArray objectAtIndex:indexPath.row]];
    [_singleRecipePassing addObject:[_superRecipe.ratingArray objectAtIndex:indexPath.row]];
    [_singleRecipePassing addObject:[_superRecipe.timeArray objectAtIndex:indexPath.row]];
    [_singleRecipePassing addObject:[_superRecipe.idArray objectAtIndex:indexPath.row]];

    // Code to flip to the next view, removed until further discussion
    [self performSegueWithIdentifier:@"recipeViewSegue" sender:self];
}

- (void)recipeViewControllerDidFinish:(recipeViewController *)controller
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    _transportArray2 = controller.holdFavs;
}


#pragma mark - Actions

- (IBAction)Done_Button:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.delegate namesFlipsideViewControllerDidFinish:self];
}


@end