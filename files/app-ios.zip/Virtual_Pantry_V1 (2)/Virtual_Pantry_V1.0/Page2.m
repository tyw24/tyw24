//
//  Page2.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import "Page2.h"
#import "namesFlipsideViewController.h"

@interface Page2 ()

@end

@implementation Page2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Declare App Delegate in page
    _appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // USE THIS TO GET THE ITEMS IN PANTRY: _appDelegate.myPantry.inventoryArray
    
    // Create tab icon
    UIImage *homeImage = [UIImage imageNamed:@"Recipe.png"];
    self.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Recipes" image:homeImage tag:0];
    
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"BlueBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    // Do any additional setup after loading the view.
    
    _allergiesDiets = @[@"Dairy", @"Peanut", @"Gluten", @"Vegan", @"Vegetarian"];
    _selectedItems = [[NSMutableArray alloc] init];
    for (int i = 0; i < [_allergiesDiets count]; i++) {
        [_selectedItems addObject:[NSNumber numberWithBool:NO]];
        _pantryActivated = false;
    }
    
    //error messages
    _failure = [[UIAlertView alloc]
                initWithTitle:@"Error"
                message:@"You left the text box blank."
                delegate:nil
                cancelButtonTitle:@"Uh.. Okay.."
                otherButtonTitles:nil];
    _failure2 = [[UIAlertView alloc]
                 initWithTitle:@"Error"
                 message:@"Unable to connect to internet."
                 delegate:nil
                 cancelButtonTitle:@"Hmm.."
                 otherButtonTitles:nil];
}

//This makes it so you can click off the keyboard and it will disappear.
- (IBAction)dismissKeyboardOnTap:(id)sender {
    //Page3 *controller = (Page3 *)segue.destinationViewController; // Declare controller
    //controller. = _pantryArray; //pass data from pantry array to a local array in Ingredient_TableView
    //NSLog(@"%@", _currentPantry);
    [[self view] endEditing:YES];
}

- (IBAction)itemAllRecipes:(id)sender {
    //-------------------------------------------------------------------------------------------------------------------------
    //------------------------------THIS IS FOR GETTING ALL RECIPES THAT USE CERTAIN INGREDIENTS-------------------------------
    //-------------------------------------------------------------------------------------------------------------------------
    
    NSMutableArray *ingredients = [[NSMutableArray alloc] initWithObjects:@"eggs", @"milk", @"bread", @"syrup", nil];
    
    NSString *searchURLName1;
    NSString *searchURLName2;
    
    NSMutableArray *variations = [[NSMutableArray alloc] init];
    
    NSString *searchURLName = @"http://api.yummly.com/v1/api/recipes?_app_id=4463c582&_app_key=826ed0572175a6597d8e748bee827d66&q=";
    searchURLName = [searchURLName stringByAppendingString:@"&allowedIngredient[]="];
    
    if([ingredients count] > 1)
    {
        searchURLName1 = [searchURLName stringByAppendingString:ingredients[1]];
        searchURLName2 = [searchURLName stringByAppendingString:ingredients[2]];
        
        searchURLName1 = [searchURLName1 stringByAppendingString:@"&maxResult=100"];
        searchURLName1 = [searchURLName2 stringByAppendingString:@"&maxResult=100"];
        
        NSURL *searchURL1 = [NSURL URLWithString:[searchURLName1 stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding]];
        NSMutableArray *searchResults1 = [NSMutableArray alloc];
        
        NSData *searchResultsDictionary1 = [NSData dataWithContentsOfURL:searchURL1];
        
        @try {
            searchResults1 = [NSJSONSerialization
                              JSONObjectWithData:searchResultsDictionary1
                              options:NSJSONReadingMutableContainers
                              error:nil];
        }
        @catch (NSException *exception) {
            [_failure2 show];
        }
        
        
        NSURL *searchURL2 = [NSURL URLWithString:[searchURLName2 stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding]];
        NSMutableArray *searchResults2 = [NSMutableArray alloc];
        
        NSData *searchResultsDictionary2 = [NSData dataWithContentsOfURL:searchURL2];
        
        @try {
            searchResults2 = [NSJSONSerialization
                              JSONObjectWithData:searchResultsDictionary2
                              options:NSJSONReadingMutableContainers
                              error:nil];
        }
        @catch (NSException *exception) {
            [_failure2 show];
        }
        
        NSMutableArray *updatedSearches = [[NSMutableArray alloc] init];
        VPRecipe *recipeSet1 = [[VPRecipe alloc] initWithArray:searchResults1];
        VPRecipe *recipeSet2 = [[VPRecipe alloc] initWithArray:searchResults2];
        updatedSearches = recipeSet1.nameArray;
        int holdmate;
        
        for(int i = 0; i < [recipeSet2.nameArray count]; i++)
        {
            NSString* holder = recipeSet2.nameArray[i];
            
            for(int j = 0; j < [recipeSet1.nameArray count]; j++)
            {
                if([holder isEqualToString: recipeSet1.nameArray[i]])
                {
                    holdmate++;
                }
            }
            
            if(holdmate == 0)
            {
                [updatedSearches addObject:recipeSet2.nameArray[i]];
            }
        }
        
        [variations addObject:updatedSearches];
        
        for(int q = 2; q < [ingredients count]; q++)
        {
            
            NSString* searchURLNameNew = [searchURLName stringByAppendingString:ingredients[q]];
            NSURL *newSearchURL = [NSURL URLWithString:[searchURLNameNew stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding]];
            NSMutableArray *searchResults = [NSMutableArray alloc];
            
            NSData *searchResultsDictionary = [NSData dataWithContentsOfURL:newSearchURL];
            
            @try {
                searchResults = [NSJSONSerialization
                                 JSONObjectWithData:searchResultsDictionary
                                 options:NSJSONReadingMutableContainers
                                 error:nil];
            }
            @catch (NSException *exception) {
                [_failure2 show];
            }
            
            updatedSearches = variations[q-2];
            
            variations[q-1] = [[NSMutableArray alloc] init];
            variations[q-1] = variations[q-2];
            
            VPRecipe *recipeSet = [[VPRecipe alloc] initWithArray:searchResults];
            
            for(int i = 0; i < [recipeSet.nameArray count]; i++)
            {
                //NSLog(@"YOO%lu", (unsigned long)[updatedSearches count]);
                NSString* holder = recipeSet.nameArray[i];
                
                int holdmate;
                for(int j = 0; j < [variations[q-2] count]; j++)
                {
                    //NSLog(@"recipename2: %@", recipeSet2.nameArray[j]);
                    if([holder isEqualToString: variations[q-2][j]])
                    {
                        holdmate++;
                    }
                    if(holdmate == 0)
                    {
                        [variations[q-1] addObject:recipeSet.nameArray[j]];
                    }
                    [variations addObject:updatedSearches];
                    
                }
            }
        }
    }
    else {
        //YOU WILL ACCOUNT FOR 1 INGREDIENT SEARCHES
    }
    
    for(int i = 0; i < [variations count]; i++)
    {
        //NSLog(@"Variation : \n%@", variations[i]);
    }
    //return variations[[variations count]];
}

//Method that calls information from a website
-(void)callToWeb {
    
    NSString *input = _search.text;
    input = [input stringByReplacingOccurrencesOfString:@" "
                                             withString:@"+"];
    NSString *searchURLName = [@"http://api.yummly.com/v1/api/recipes?_app_id=4463c582&_app_key=826ed0572175a6597d8e748bee827d66&q=" stringByAppendingString:input];
    
    if ([_selectedItems[0] boolValue])
    {
        searchURLName = [searchURLName stringByAppendingString:@"&allowedAllergy[]=396^Dairy-Free"];
    }
    
    if ([_selectedItems[1] boolValue])
    {
        searchURLName = [searchURLName stringByAppendingString:@"&allowedAllergy[]=393^Gluten-Free"];
    }
    
    // Check end point for peanut free recipes
    if ([_selectedItems[2] boolValue])
    {
        searchURLName = [searchURLName stringByAppendingString:@"&allowedAllergy[]=394^Peanut-Free"];
    }
    
    // Check end point for vegan only recipes
    if ([_selectedItems[3] boolValue])
    {
        searchURLName = [searchURLName stringByAppendingString:@"&allowedDiet[]=386^Vegan"];
    }
    
    // Check end point for vegatarian only recipes
    if ([_selectedItems[4] boolValue])
    {
        searchURLName = [searchURLName stringByAppendingString:@"&allowedDiet[]=387^Lacto-ovo%20vegetarian"];
    }
    
    searchURLName = [searchURLName stringByAppendingString:@"&requirePictures=true&maxResult=20&start=10"];
    
    if(_pantryActivated)
    {
        for(int i=0; i < [_appDelegate.myPantry.inventoryArray count]; i++)
        {
    searchURLName = [searchURLName stringByAppendingString: @"&allowedIngredient[]="];
    searchURLName = [searchURLName stringByAppendingString: _appDelegate.myPantry.inventoryArray[i]];
    
        }
    }
    
    NSURL *searchURL = [NSURL URLWithString:[searchURLName stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding]];
    
    NSData *searchResultsDictionary = [NSData dataWithContentsOfURL:searchURL];
    
    @try {
        _searchResults = [NSJSONSerialization
                                         JSONObjectWithData:searchResultsDictionary
                                         options:NSJSONReadingMutableContainers
                                         error:nil];
    }
    @catch (NSException *exception) {
        [_failure2 show];
    }
}

//Call web info from a website when button is pressed
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)GetRecipesAndShow:(id)sender {
    [self callToWeb];
}

#pragma mark - PickerView

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    return _allergiesDiets.count;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    
    pickerView = [[UIPickerView alloc] initWithFrame:CGRectZero];
    
        pickerView.delegate = self;
        pickerView.dataSource = self;
        pickerView.showsSelectionIndicator = YES;
        pickerView.transform = CGAffineTransformMakeScale(0.5, 0.5);

    UITableViewCell *cell = (UITableViewCell *)view;
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    [cell setBounds: CGRectMake(0, 0, cell.frame.size.width -20 , 44)];
    [cell.textLabel setTextColor:[UIColor blackColor]];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    cell.textLabel.text = [self.allergiesDiets objectAtIndex:row];
    cell.userInteractionEnabled = NO;
    
    if( _selectedItems[row] == [NSNumber numberWithBool:NO] ) {
        [cell setBackgroundColor:[UIColor colorWithRed:207.0/255.0 green:231.0/255.0 blue:239/255.0 alpha:1]];
    }
    else if( _selectedItems[row] == [NSNumber numberWithBool:YES]) {
        [cell setBackgroundColor:[UIColor whiteColor]];
    }
    
    return cell;
}


-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    if(_selectedItems[row] == [NSNumber numberWithBool:YES]){
        _selectedItems[row] = [NSNumber numberWithBool:NO];
        //[(UIView*)[[pickerView subviews] objectAtIndex:row] setAlpha:0.5f];
        NSLog(@"%@", _selectedItems);
        [pickerView reloadComponent:component];
    }
    else if(_selectedItems[row] == [NSNumber numberWithBool:NO]){
        _selectedItems[row] = [NSNumber numberWithBool:YES];
        NSLog(@"%@", _selectedItems);
        [pickerView reloadComponent:component];
    }
}

#pragma mark - Flipside View

- (void)namesFlipsideViewControllerDidFinish:(namesFlipsideViewController *)controller
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    _transportArray = controller.transportArray2;
    NSLog(@"%@", _transportArray);
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showAlternate"]) {
        namesFlipsideViewController *controller = (namesFlipsideViewController *)segue.destinationViewController;
        controller.searchResults1 = _searchResults;
        /*//FOR PASSING DATA BETWEEN CONTROLLERS
        Page1 * acontollerobject= [[Page1 alloc] init];
        // protocol listener
        acontollerobject.delegate=self;
        //push values to viewcontroller
        [self.navigationController pushViewController:acontollerobject animated:YES];
        
        acontollerobject.appDelegate.myPantry.inventoryArray = ;
        
        acontollerobject.appDelegate.favoriteRecipes.inventoryArray = _holdFavs;
        
        [acontollerobject.appDelegate.favoriteRecipes save]; //store to memory permenantly
        [[segue destinationViewController] setDelegate:self];*/
    }
}


- (IBAction)useAllPantryItems:(id)sender {
    if(_pantryActivated)
    {
        _pantryActivated = false;
    }
    else{
        _pantryActivated = true;
    }
}
@end
