//
//  nutritionViewController.m
//  Virtual_Pantry_V1.0
//
//  Created by Edward Aryee on 5/31/14.
//  Copyright (c) 2014 Edward Aryee. All rights reserved.
//

#import "nutritionViewController.h"
#import "AppDelegate.h"


@interface nutritionViewController ()

@end

@implementation nutritionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Declare App Delegate in page
    _appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // Do any additional setup after loading the view.
    NSArray *nutrition = [_appDelegate.recipeInformation valueForKey:@"nutritionEstimates"];
    
   // NSMutableArray *nutritionInfo = [NSMutableArray alloc];
    
    NSLog(@"%@", nutrition);    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
