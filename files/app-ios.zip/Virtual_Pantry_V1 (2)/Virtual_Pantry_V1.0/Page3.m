//
//  Page3.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//
#ifndef __mydefinition2__
#define __mydefinition2__
#import "Page3.h"

@interface Page3 ()

@end

@implementation Page3

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Declare App Delegate in page
    _appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // TAB BAR ICON
    UIImage *homeImage = [UIImage imageNamed:@"Pantry.png"];
    self.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Pantry" image:homeImage tag:0];
    
    //CREATING FRAME
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"YellowBack.png"] drawInRect:self.view.bounds];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    
    
    //error messages
    _failure = [[UIAlertView alloc]
                initWithTitle:@"Error"
                message:@"You left the text box blank."
                delegate:nil
                cancelButtonTitle:@"Uh.. Okay.."
                otherButtonTitles:nil];
    
    
    [_appDelegate.myPantry save];
}

//ALL THINGS TABLEVIEW
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_appDelegate.myPantry.inventoryArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [_appDelegate.myPantry.inventoryArray objectAtIndex:indexPath.row];
    [cell setBackgroundColor:[UIColor clearColor]];
    [cell.textLabel setBackgroundColor:[UIColor clearColor]];
    return cell;
}

//This makes it so you can click off the keyboard and it will disappear.
- (IBAction)dismissKeyboardOnTap:(id)sender {
    [[self view] endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Removed From Pantry" message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    //remove stuff at the clicked cell from the pantry array
    [_appDelegate.myPantry.inventoryArray removeObject:[_appDelegate.myPantry.inventoryArray objectAtIndex:indexPath.row]];
    [_appDelegate.myPantry save]; //store to memory permenantly
    [_Pantry_Table_View performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO]; // reset table
}


#pragma mark - Ingredient Table View

- (void)Ingredient_TableViewDidFinish:(Ingredient_TableView *)controller
{
    //dismiss the ingredient view controller
    [self dismissViewControllerAnimated:YES completion:nil];
    //reset the VPStorage object's inventory array to the pantryArray which has been updated. The VPStorage object can be saved, while a regular array cannot.
    [_appDelegate.myPantry save]; //store to memory permenantly
    [_Pantry_Table_View performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO]; //reset tableview
}

//FOR PASSING DATA BETWEEN CONTROLLERS
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    //TO RECIPE VIEW CONTROLLER
    if ([[segue identifier] isEqualToString:@"showAlternate"]) {
        Ingredient_TableView *controller = (Ingredient_TableView *)segue.destinationViewController; // Declare controller
        controller.addedObjects = _appDelegate.myPantry.inventoryArray; //pass data from pantry array to a local array in Ingredient_TableView
        [[segue destinationViewController] setDelegate:self];
    }
}

@end
#endif

