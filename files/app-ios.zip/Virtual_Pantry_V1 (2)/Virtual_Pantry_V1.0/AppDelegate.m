//
//  AppDelegate.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/29/2014.
//  Copyright (c) 2014 ___FULLUSERNAME___. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize myPantry;




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [application setApplicationSupportsShakeToEdit:YES];
    
    _recipeInformation = [NSMutableArray alloc];
    
    _window.frame = CGRectMake(0, 0, _window.frame.size.width,568);
    
    if(myPantry == nil)
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSString *filePath = [NSString stringWithFormat:@"%@/database", documentsDirectory];
        
        
        myPantry = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        if(myPantry == nil)
        {
            myPantry = [[VPStorage alloc] init];
            [myPantry save];
        }
    }
    
    if(_favoriteRecipes == nil)
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        NSString *filePath = [NSString stringWithFormat:@"%@/database2", documentsDirectory];
        
        
        _favoriteRecipes = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        if(_favoriteRecipes == nil)
        {
            _favoriteRecipes = [[VPStorage2 alloc] init];
            [_favoriteRecipes save];
        }
    }
    
    return YES;
}


// Create coder to save data to a directory on device
- (id)init:(int*) x
{

    
    
    return self;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such 1as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    //Save data
    Page3 * acontollerobject=[[Page3 alloc] init];
    acontollerobject.delegate=self;
    //[acontollerobject.pantryObject save];
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    //Save data
    //[acontollerobject.pantryObject save];
    
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
