//
//  MyManager.m
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 5/23/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//

#import "MyManager.h"

@implementation MyManager

@synthesize storageObject;

#pragma mark Singleton Methods

+ (id)sharedManager {
    static MyManager *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

- (id)init {
    if (self = [super init]) {
        storageObject = [[VPStorage alloc] init];
    }
    return self;
}

- (void)updateStorageObject: (VPStorage *) newObject
{
    storageObject = newObject;
}

//[[MyManager sharedManager] storageObject]

- (void)dealloc {
    // Should never be called, but just here for clarity really.
}

@end