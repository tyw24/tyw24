//
//  Page3.h
//  Virtual_Pantry_V1.0
//
//  Created by Stevie Parris on 4/30/2014.
//  Copyright (c) 2014 Stevie Parris. All rights reserved.
//
#ifndef __mydefinition__
#define __mydefinition__

#import <UIKit/UIKit.h>
#import "VPStorage.h"
#import "Ingredient_TableView.h"
#import "Page2.h"
#import "MyManager.h"
#import "AppDelegate.h"

@interface Page3 : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextViewDelegate, UITextFieldDelegate, Ingredient_TableViewDelegate, AppDelegate>

//Declare default error message
@property (strong, nonatomic) UIAlertView *failure;

//Temporary array where items displayed in tableView are stored
//@property (strong, nonatomic) NSMutableArray *pantryArray;

//Declare the app delegate
@property (strong, nonatomic) AppDelegate *appDelegate;

//Tableview object
@property (weak, nonatomic) IBOutlet UITableView *Pantry_Table_View;

//The delegate used to get data back and forth
@property(nonatomic,assign)id delegate;

//This is the VPStorage object used to store all the recipes in the pantry. This can be saved, to keep data after program termination
@property(nonatomic) VPStorage * pantryObject;

//Used to allow user to press on page and turn off keyboard
- (IBAction)dismissKeyboardOnTap:(id)sender;

#pragma mark - Ingredient Table View

//Called upon finishing with Ingredient Tableview, to dismiss the controller and pass the data values between controllers.
- (void)Ingredient_TableViewDidFinish:(Ingredient_TableView *)controller;

//Initializes segue between controllers and passes the pantryArray to be updated.
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;

@end
#endif